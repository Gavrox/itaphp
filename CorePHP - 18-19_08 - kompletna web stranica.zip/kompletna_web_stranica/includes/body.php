<div id="wrapper">
<div id="bg"></div>
<div id="overlay"></div>
<div id="main">

    <!-- Header -->
        <?php require_once 'header.php'; ?>
    
    <!-- Main data (place to add something which is not in original design) -->
        <?php require_once 'main.php'; ?>

    <!-- Footer -->
        <?php require_once 'footer.php'; ?>

</div>
</div>