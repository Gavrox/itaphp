<header id="header">
    <?php
        require_once 'privateData.php';
        require_once 'socialData.php';
    ?>
            
</header>