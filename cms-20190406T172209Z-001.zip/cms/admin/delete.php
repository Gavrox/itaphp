<?php

session_start();

include_once "../includes/connection.php";
include_once "../includes/article.class.php";

$article = new Article;

if (isset($_SESSION['logged_in'])) {

$articles = $article->fetch_all();
//	
	?>
<html>
	<head>
		<title>Delete article</title>
		<link rel="stylesheet" href="../style/style.css"> 
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384- 	JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	</head>
	<body>
		<div class="container">
		
			<a href="index.php" id="logo">CMS</a>
            <br>
          	<h1>Delete Article</h1>
          	<form action="delboy.php" method="post">
					
					<?php 
					foreach ($articles as $article)
					{

						echo "<div class=\"form-group form-check\">";

						echo "<input type='checkbox' class=\"form-check-input\" name='checkbox' value='".$article['article_id']."'>";
						echo "<label class=\"form-check-label\" for=\"checkbox\">".$article['article_title']."</label>";
						echo "</div>";
					}
					?>
				<br>
				<input class="btn btn-primary" type="submit" name="delete" id="delete" value="Delete">
			</form>
		</div>	
	</body>
</html>

	<?php
				
}else{
	header('Location: index.php');
}

?>
